# Fletore e Lutjes — PWA

## Si ta instalosh si aplikacion në telefon

### Hapi 1 — Ngarko skedaret në Netlify (falas, 2 minuta)

1. Shko te: https://app.netlify.com/drop
2. Zgjidh të gjithë skedaret brenda kësaj dosjeje (index.html, manifest.json, sw.js, icon.svg, icon-192.png, icon-512.png)
3. Tërhiqji dhe lëshoji në faqen e Netlify
4. Prit 10 sekonda — do të marrësh një link si: https://emri-random.netlify.app

### Hapi 2 — Instalo në iPhone

1. Hap linkun e Netlify në **Safari** (jo Chrome)
2. Tasto Share (□↑) poshtë ekranit
3. Scrollo dhe tasto **"Add to Home Screen"**
4. Shkruaj emrin: **Fletore e Lutjes**
5. Tasto **Add**

### Hapi 2 — Instalo në Android

1. Hap linkun e Netlify në **Chrome**
2. Tasto tre pikat (⋮) lart djathtas
3. Tasto **"Add to Home Screen"** ose **"Install app"**
4. Konfirmo

---

## Karakteristika PWA

- ✅ Punon offline (pa internet) pas instalimit
- ✅ Ikonë e dedikuar në ekranin kryesor
- ✅ Hapet pa shiritin e browser-it (si app e vërtetë)
- ✅ Të dhënat ruhen në telefon (localStorage)
- ✅ Ruajtje automatike çdo 2 minuta

---

Skedaret: index.html · manifest.json · sw.js · icon.svg · icon-192.png · icon-512.png
